# FortinaGalluccio
Software Engineering 2 Project
Overleaf link of the latex, view only :https://www.overleaf.com/read/nhncrtkkxrcb
